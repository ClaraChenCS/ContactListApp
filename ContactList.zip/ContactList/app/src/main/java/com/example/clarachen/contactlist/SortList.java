package com.example.clarachen.contactlist;

import android.util.Log;

import java.util.Comparator;

/**
 * Created by ClaraChen on 10/16/17.
 */

public class SortList implements Comparator<String> {
    //Sorting Contact list by number of vowels in names by descending order
    @Override
    public int compare(String o1, String o2) {
        Log.d("Sorting >>> ","Contact Lists");
        Log.d(".....", String.valueOf(count(o1)-count(o2)+o1+ "  "+ o2));
        return o2.replaceAll("[^aeiouAEIOU]", "").length()
                - o1.replaceAll("[^aeiouAEIOU]", "").length();
    }

    private int count(String s) {
        int cnt = 0;
        for (int i=0; i<s.length(); i++) {
            char c = s.charAt(i);
            if(c=='a' || c=='e' || c=='i' || c=='o' || c=='u' || c=='A' || c=='E' || c=='I' || c=='O' || c=='U'){
                cnt++;
            }
        }
        Log.d("count>>>",String.valueOf(cnt));
        return cnt;
    }
}
