package com.example.clarachen.contactlist;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.preference.SwitchPreference;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.preference.PreferenceManager;
import android.support.v7.preference.SwitchPreferenceCompat;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class ContactActivity extends AppCompatActivity{

    // Contacts ListView
    private ListView listNames;
    // Read settings
    public static SharedPreferences sharedPref;

    // default access to contact = false
    public boolean switchPref = false;
    public static boolean sFlag = false;

    private static final int PERMISSION_REQUEST_READ_CONTACTS = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Sets default values only once
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
        setContentView(R.layout.activity_contact);

        // Find Toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Find floating button
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //Find the list view
        this.listNames =(ListView) findViewById(R.id.listNames);
        sharedPref = PreferenceManager.getDefaultSharedPreferences(this);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[] {Manifest.permission.READ_CONTACTS}, PERMISSION_REQUEST_READ_CONTACTS);
            sFlag =true;
            showContactsList();
        }
    }

    @Override
    protected void onResume(){
        super.onResume();

        if(SettingsFragment.CONTACT_PREF_SWITCH!=null){
            switchPref=sharedPref.getBoolean(SettingsFragment.CONTACT_PREF_SWITCH,false);
            if(switchPref ==true){
                showContactsList();
            }
        }else{
           showEmptyContactList();
        }
    }
    /**
     * Read and Show the contacts in the ListView
     */
    @TargetApi(Build.VERSION_CODES.M)
    private void showContactsList(){

            if(sFlag == true && switchPref==true){
                List<String> contactNames = getContactNames();
//            //Sort Contact List by number of vowels in names by descending order
                Collections.sort(contactNames, new SortList());

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,contactNames);
                listNames.setAdapter(adapter);
            } else {
                changeSettingPref(false);
                Toast.makeText(this, "Permission denied. Please Turn on the permission in Setting!", Toast.LENGTH_SHORT).show();
            }
    }

    /**
     * show empty list
     */
    private void showEmptyContactList(){
        List<String> contactNames= new ArrayList<String>();
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,contactNames);
        listNames.setAdapter(adapter);
    }

    /**
     * Read all the contacts
     * @return list of contact names
     */
    private List<String> getContactNames(){
        List<String> contacts = new ArrayList<>();
        ContentResolver contentResolver = getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI,null,null,null,null);

        if(cursor.moveToFirst()){
            do{
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME));
                contacts.add(name);

            }while (cursor.moveToNext());
        }
        cursor.close();
        return contacts;
    }

    private void changeSettingPref(boolean prefSwitch){
        SharedPreferences.Editor editor = sharedPref.edit();
        if(prefSwitch){
            editor.putBoolean(SettingsFragment.CONTACT_PREF_SWITCH,true);
        }else {
            editor.putBoolean(SettingsFragment.CONTACT_PREF_SWITCH,false);

        }
        editor.commit();
        switchPref=sharedPref.getBoolean(SettingsFragment.CONTACT_PREF_SWITCH,prefSwitch);

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permission, int[] grantResults){
        if(requestCode == PERMISSION_REQUEST_READ_CONTACTS){
            if(grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    changeSettingPref(true);
                    showContactsList();
            } else {
                    changeSettingPref(false);
                    Toast.makeText(this,"Permission denied. Please Turn on the permission in Setting!", Toast.LENGTH_SHORT).show();
            }

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_contact, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            Intent intent = new Intent(ContactActivity.this, SettingsActivity.class);
            Log.d("Before Broadcast",String.valueOf(switchPref));
            intent.putExtra("prefSwitchValue",switchPref);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
