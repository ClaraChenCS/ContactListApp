package com.example.clarachen.contactlist;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.app.Fragment;
import android.support.v7.preference.Preference;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.support.v7.preference.PreferenceManager;
import android.support.v7.preference.SwitchPreferenceCompat;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsFragment extends PreferenceFragmentCompat {

    public static final String CONTACT_PREF_SWITCH = "access_contacts";

    public static SwitchPreferenceCompat contactSwitch;
    public static SharedPreferences sharedPreferences = ContactActivity.sharedPref;
    public static boolean cSwitch;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.preferences, rootKey);
        contactSwitch = (SwitchPreferenceCompat) findPreference("contacts_switch");
        cSwitch = SettingsActivity.switchValue;
        String c = String.valueOf(cSwitch);
        if (cSwitch) {
            contactSwitch.setChecked(cSwitch);
            contactSwitch.setDefaultValue(cSwitch);
            sharedPreferences.edit().putBoolean(CONTACT_PREF_SWITCH, cSwitch).commit();
        } else {
            contactSwitch.setChecked(cSwitch);
            contactSwitch.setDefaultValue(cSwitch);
            sharedPreferences.edit().putBoolean(CONTACT_PREF_SWITCH, cSwitch).commit();
        }
        Log.d("Contact Switch>>>>>>>>", c);
    }
    @Override
    public void onPause(){
        sharedPreferences.edit().putBoolean(CONTACT_PREF_SWITCH,contactSwitch.isChecked()).commit();
        Log.d("Contact Switch>Pause>>>", String.valueOf(contactSwitch.isChecked()));
        super.onPause();
    }

}